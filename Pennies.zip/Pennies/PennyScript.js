let numberPennies = 23;
/*Complete these three lines of code to grab the correct elements
from the HTML file to set up the program. */
let info = document.getElementById('');
let feedback = document.getElementById('');
let pieces = document.getElementById('');

let intro = "<h3>23 Pennies</h3>";
intro += "Take turns removing 1, 2, or 3 pennies. ";
intro += "Whoever takes the last penny loses. "
info.innerHTML = intro;

displayPennies();

/*updates the pieces div in the HTML to display the proper number of 'pennies' */
function displayPennies() {
    
}

/*This is the players turn, each button in the HTML will call this function when clicked on 
by the player, sending the corresponding number of pennies selected to the function and updating
the game. */
function take(num) {
    //enter all code here
    setTimeout(() => {computerTurn();}, 1500); //last line of the function
}

/*This is the computer's turn, it should have the computer select a number of pennies, check to see
if it lost, and update the game.*/
function computerTurn(){
    
}

/*This function will reset the game board and the game will start fresh*/
function reset() {
    
}